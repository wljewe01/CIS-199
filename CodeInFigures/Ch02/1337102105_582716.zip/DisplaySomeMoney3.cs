using static System.Console;
class DisplaySomeMoney3
{
   static void Main()
   {
      double someMoney = 39.45;
      WriteLine("The money is ${0} exactly", someMoney);
   }
}
