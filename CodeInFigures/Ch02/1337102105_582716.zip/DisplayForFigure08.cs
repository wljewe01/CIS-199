using static System.Console;
class DisplaySForFigure08
{
   static void Main()
   {
      WriteLine("{0}", 4);
      WriteLine("{0}", 56);
      WriteLine("{0}", 789);
   }
}
